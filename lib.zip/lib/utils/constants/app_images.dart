class AppImages {
  static const String burger = 'assets/image_icons/burger.jpg';
  static const String pizza = 'assets/image_icons/pizza.jpg';
  static const String indianFood = 'assets/image_icons/indian_food.jpg';
  static const String japanese = 'assets/image_icons/japanese_food.jpg';
}
